module golang.org/x/mod

go 1.24.0

require golang.org/x/tools v0.41.0 // tagx:ignore
