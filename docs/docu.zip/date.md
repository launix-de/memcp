# Date

## now

returns the unix timestamp

**Allowed number of parameters:** 0–0

### Parameters

_This function has no parameters._

### Returns

`int`

## parse_date

parses unix date from a string

**Allowed number of parameters:** 1–1

### Parameters

- **value** (`string`): values to parse

### Returns

`int`

