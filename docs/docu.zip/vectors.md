# Vectors

## dot

produced the dot product

**Allowed number of parameters:** 2–3

### Parameters

- **v1** (`list`): vector1
- **v2** (`list`): vector2
- **mode** (`string`): DOT, COSINE, EUCLIDEAN, default is DOT

### Returns

`number`

